package com.mycompany.assignmentmaster

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
