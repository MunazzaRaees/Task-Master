import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyC3tzfYhyMvYhTH5nOWH4Xr7_ERPuCJBEM",
            authDomain: "assignment-master.firebaseapp.com",
            projectId: "assignment-master",
            storageBucket: "assignment-master.appspot.com",
            messagingSenderId: "244946515274",
            appId: "1:244946515274:web:867199036c27f1f7253db3",
            measurementId: "G-E99TP3VMNC"));
  } else {
    await Firebase.initializeApp();
  }
}
